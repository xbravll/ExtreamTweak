#!/system/bin/sh
# Dijalankan sebagai bagian dari Magisk Module
# LENIRRAxZONE | FEBRYAN

# Tunggu sampai sistem boot sepenuhnya
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

# Tunggu beberapa detik lagi untuk memastikan semua layanan berjalan
sleep 20

# ========================
# OPTIMASI CPU & GOVERNOR
# ========================

# Set governor ke schedutil untuk keseimbangan performa/baterai
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "schedutil" > $cpu 2>/dev/null
done

# ========================
# OPTIMASI MEMORI
# ========================

# Set parameter kernel VM
echo "10" > /proc/sys/vm/swappiness 2>/dev/null
echo "90" > /proc/sys/vm/dirty_ratio 2>/dev/null
echo "70" > /proc/sys/vm/dirty_background_ratio 2>/dev/null
echo "3000" > /proc/sys/vm/dirty_expire_centisecs 2>/dev/null
echo "500" > /proc/sys/vm/dirty_writeback_centisecs 2>/dev/null
echo "0" > /proc/sys/vm/laptop_mode 2>/dev/null

# Opsi LMK (Low Memory Killer) untuk manajemen RAM yang lebih baik
if [ -e /sys/module/lowmemorykiller/parameters/minfree ]; then
    echo "18432,23040,27648,32256,55296,80640" > /sys/module/lowmemorykiller/parameters/minfree 2>/dev/null
fi

# ========================
# OPTIMASI I/O
# ========================

# Set scheduler I/O untuk performa
for block in /sys/block/*/queue; do
    echo "deadline" > "$block/scheduler" 2>/dev/null
    echo "0" > "$block/add_random" 2>/dev/null
    echo "0" > "$block/iostats" 2>/dev/null
    echo "1" > "$block/nomerges" 2>/dev/null
    echo "0" > "$block/rotational" 2>/dev/null
    echo "1" > "$block/rq_affinity" 2>/dev/null
    echo "256" > "$block/read_ahead_kb" 2>/dev/null
done

# ========================
# OPTIMASI GPU
# ========================

# Optimalkan GPU Adreno pada perangkat Snapdragon
if [ -e /sys/class/kgsl/kgsl-3d0 ]; then
    echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null
    echo "1" > /sys/class/kgsl/kgsl-3d0/force_rail_on 2>/dev/null
    echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null
    echo "0" > /sys/class/kgsl/kgsl-3d0/throttling 2>/dev/null # Matikan GPU Throttling (hati-hati)
    echo "0" > /sys/class/kgsl/kgsl-3d0/bus_split 2>/dev/null
    echo "1" > /sys/class/kgsl/kgsl-3d0/force_no_nap 2>/dev/null
fi

# Set GPU governor jika tersedia
if [ -e /sys/class/kgsl/kgsl-3d0/devfreq/governor ]; then
    echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
fi

# ========================
# OPTIMASI JARINGAN
# ========================

# Optimalkan TCP
echo "westwood" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
echo "1" > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null

# ========================
# THERMAL ZONE
# ========================

# Matikan thermal throttling (PERHATIAN: Bisa menyebabkan perangkat terlalu panas!)
# Loop melalui thermal_zone0 hingga thermal_zone7
for i in {0..7}; do
    zone_path="/sys/class/thermal/thermal_zone${i}/mode"
    if [ -e "$zone_path" ]; then
        echo "disabled" > "$zone_path" 2>/dev/null
    fi
done

# Log bahwa script telah dijalankan
echo "$(date) Performance Module: Semua optimasi telah diterapkan" > /sdcard/perf_log.txt

exit 0