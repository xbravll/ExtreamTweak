SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"
REPLACE="
"
print_modname() {

ui_print "==========================================="
ui_print "          Welcome to LENIRRAxZONE.             "
ui_print "       CREATED BY @xbravll | FEBRYAN           "
ui_print "==========================================="
echo -n "- Date&Time: "
date "+%c"
sleep 1
ui_print "check information device"
sleep 1
ui_print "• Device           : $(getprop ro.product.name) "
sleep 0.3
ui_print "• Android version : $(getprop ro.build.version.release) "
sleep 0.3
ui_print "• SDK              : $(getprop ro.build.version.sdk) "
sleep 0.3
ui_print "• CPU_ABI         : $(getprop ro.product.cpu.abi) "
sleep 0.3
ui_print "• Hardware        : $(getprop ro.boot.hardware) "
sleep 0.3
ui_print "• Rom             : $(getprop ro.build.display.id) "
sleep 0.3
ui_print "• Kernel           : $(uname -r) "
sleep 2
# Inform user that the script is working
ui_print "Initializing setup... please wait."

}
set_permissions() {
set_perm_recursive $MODPATH 0 0 0755 0644
}